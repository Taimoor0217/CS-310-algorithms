// Algorithm:
	// Each team wants to go to its final destination, so the prefrences list of the team would be its final location , followed by its second last location and so on.
	// So initially the team goes to the location , it prefers the most. In case, that location is already occupied, this means that there are more that one teams
	// which want to go to the same location on the same day. Now the location decides which of the teams to be kept. Based on its preference for the teams.
	// The prefrence of a location for a team has been defined as follows, "A location prefers a team, to which it is closest."
// Data Structures:
	// The data structures, used are quite similar to question no 1. Except for 1 change, in addition to the a of prefrences for locations, it now also contains a vector of distances of each location from it. 
	// This way, the preferences of the locations for the teams have been decided.
// Space : O(n^2)
// Time  : O(n^2)
#include <iostream>
#include <string.h> 
#include <sstream>
#include <cstdlib>
#include <vector>
#include <stdio.h>
#include <string>
#include <fstream>
using namespace std;
struct team;
struct location{
	string name;
	team* assigned = NULL;
	location(string n){
		name = n;
		assigned = NULL;
	}
};
struct team{
	string name;
	std::vector<location*> Prefrences;
	std::vector<int> indices;
	location* loc = NULL;
	team(string n){
		name = n;
		loc = NULL;
	}
};
location * find(string s , vector<location*> &v){
	for(int i = 0 ; i < v.size() ; i++){
		if(v[i]->name == s){
			return v[i];
		}
	}
	location * l = new location(s);
	v.push_back(l);
	return l ;
}
int main(){
	std::vector<team*> TEAMS;
	std::vector<location*> LOCATIONS;
	ifstream infile;
	infile.open("q2test2");
	string line;
	int LEN = 0;
	int n = 0;
	while(getline(infile , line)){
		vector<string> v;
		string temp;
		stringstream ss(line);
		while(getline(ss , temp, ' ')){
			v.push_back(temp);
		}
		if(n++){
			// cout << line << endl; 
			// cout << s << endl;
			team * t = new team(v[0]);
			TEAMS.push_back(t);
			string s = v[1];
			stringstream tt(s);
			int count = 0;
			while(getline(tt , temp, ',')){
				if(temp != "-"){
					location * l = find(temp , LOCATIONS);
					t->Prefrences.push_back(l);
					t->indices.push_back(count);
				}
				count ++;
			}
		}else{
			LEN = atoi(v[1].c_str());
		}
	}
	// for(int i = 0 ; i < TEAMS.size() ; i ++){
	// 	cout << TEAMS[i]->name <<" ";
	// 	for (int j = 0; j < TEAMS[i]->Prefrences.size(); ++j){
	// 		/* code */
	// 		cout << TEAMS[i]->Prefrences[j]->name << " " <<TEAMS[i]->indices[j];
	// 	}
	// 	cout << endl;
	// }
	// cout << LEN <<endl;
	for(int k = 0 ; k < LEN ; k++ ){
		for(int i = 0 ; i < TEAMS.size() ; i++){
			for (int j = TEAMS[i]->Prefrences.size() - 1 ; j > -1 ; j--){
				if(TEAMS[i]->loc == NULL){
					if(TEAMS[i]->Prefrences[j]->assigned == NULL){
						TEAMS[i]->Prefrences[j]->assigned = TEAMS[i];
						TEAMS[i]->loc = TEAMS[i]->Prefrences[j];
					}else{
						if(TEAMS[i]->indices[j] < TEAMS[i]->Prefrences[j]->assigned->indices[j]){
							TEAMS[i]->Prefrences[j]->assigned->loc = NULL;
							TEAMS[i]->Prefrences[j]->assigned = TEAMS[i];
							TEAMS[i]->loc =  TEAMS[i]->Prefrences[j];
						}
					}
				}
			}
		}
	}
	for(int i = 0 ; i < TEAMS.size() ; i ++){
		cout << TEAMS[i]->name <<" "<< TEAMS[i]->loc->name <<endl;
	}
}