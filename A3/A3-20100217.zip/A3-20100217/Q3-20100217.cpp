// Algorithm:
	// A recursive divide and conquer algortihm has been used. The base case would be when I have a grid of 2x2 with one box
	// already filled. I would only have to add a boomerang in the remaining three boxes;
	// So, at each step, I need to subdivide the square into sqaures with one position filled. So each each step I but 
	// three dots at the bottom of the square and not fill the square whcih already has a dot. This way we, will be left with 4 squares with
	// one dot in each. The, I recursively call the fuction on the subsquares. 
// Data Structure:
	// The board game is being represented by a 2-D array of character.
// Space: O(n^2)
// Time : O(n^2)
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
char count = 'A' ;
char empty = ' ';
void boomerang(int x ,int y , int d , int r , int c , char ** board){
	if(d == 2){
		if(board[x][y] == empty)
			board[x][y] = count;
		if(board[x+1][y] == empty)
			board[x+1][y] = count;
		if(board[x][y+1] == empty)
			board[x][y+1] = count;
		if(board[x+1][y+1] == empty)
			board[x+1][y+1] = count;
		count++;
		return;
	}else{
		if(r > x-1+ d/2 || c > y-1+ d/2){ //tl
			board[x-1 + d/2][y-1 + d/2] = count;
		} // if the forbidden one is not in the top left quarter
		// cout << x-1+ d/2 <<" " << y-1+ d/2 <<endl;
		if(r > x-1+ d/2 || c < y+ d/2){//tr
			board[x-1 + d/2][y + d/2] = count;
		}// if the forbidden one is not in the top right quarter
		// cout << x-1+ d/2 <<" " << y+ d/2 <<endl;

		if(r < x+ d/2 || c > y-1+ d/2){//bl
			board[x + d/2][y-1 + d/2] = count;
		}//if the forbidden one is not in the bottom left quarter
		// cout << x + d/2 <<" " << y-1+ d/2 <<endl;
		
		if(r < x+ d/2 || c < y+ d/2){//br
			board[x + d/2][y + d/2] = count;
		}//if the forbidden one is not in the bottom right quarter
		// cout << x + d/2 <<" " << y+ d/2 <<endl;
		count++;

		if(r > x-1+ d/2 || c > y-1+ d/2){ //tl
			boomerang(x , y , d/2 , x-1 + d/2 , y-1 + d/2 , board );
		}else{
			boomerang(x , y , d/2 , r, c, board );
		}
		if(r > x-1+ d/2 || c < y+ d/2){//tr
			boomerang(x , y+d/2 , d/2 , x-1 + d/2 , y + d/2 , board);
		}else{
			boomerang(x , y+d/2 , d/2 , x-1 + r, c, board);
		}
		if(r < x+ d/2 || c > y-1+ d/2){//bl
			boomerang(x+d/2 , y , d/2 , x + d/2 , y-1 + d/2 , board);
		}else{
			boomerang(x+d/2 , y , d/2 , r, c , board);
		}
		if(r < x+ d/2 || c < y+ d/2){//br
			boomerang(x+d/2 , y+d/2 ,d/2, x + d/2 , y + d/2 , board);
		}else{
			boomerang(x+d/2 , y+d/2 ,d/2, r, c, board);
		}

	}
}

int main(){
	// int x = 1;
	// std::string s = x);
	// cout << s ; 
	int d , r , c ;
	d = 3;
	while(d % 2 != 0){
		cout << "Enter Valid Dimensions :" ;
		cin >> d ;
	}
	cout << endl;
	cout << "Enter r:" ;cin >> r ;cout << endl;
	cout << "Enter c:" ;cin >> c ;cout << endl;
	d += 1;
	char ** board = new char*[d];
	for(int i = 1 ; i < d ; i++ ){
		board[i] = new char[d];
	}
	for(int i = 1 ; i < d ; i++ ){
		for(int j = 1 ; j < d ; j++ ){
			board[i][j] = empty;
		}
	}
	board[r][c] = '0';
	boomerang(1 , 1, d-1 , r , c , board);
	for(int k = 1 ; k < d ; k++)
		cout <<"_____";
	cout << endl;
	for(int i = 1 ; i < d ; i++ ){
		for(int j = 1 ; j < d ; j++ ){
			cout <<"|_"<<board[i][j] <<"_|";
		}cout<<endl;
	}
	
}