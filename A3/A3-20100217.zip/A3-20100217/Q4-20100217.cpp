// Algorithm:
	// The base case is when I get a node whose children do not have any children, i-t I have left with 3 nodes. In that case,
	// The value of total sum of that node becomes the sum of the value of its two children, and its side sum becomes the sum of its value and the sum of the value of the node who has maximum value.
	// both the nodes become its lnode and rnode. 
	// However, In gerneral (when not the bascase) the total sum of a node becomes the sum of the side sum of its value + value of right node and its left note and its sidesum
	// becomes equall to the sum of its value and the max side_sum value of its childern. The lnodes and rnodes are propagated to the parent from children. Another if condition check if the parents total sum is greater thatn the total sum of its children totalsum and its value.
// Datasturcture
	//I have implemented a tree using an array, The maximum ancestory is calculated by using the parent nodes of lnodes and rnodes and then reaching to the root node. 
// Space: O(n)
// Time: 2*(O(n))
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string>
using namespace std;
struct node{	
	string name ;
	node* rnode = NULL, *lnode = NULL;
	int side_sum = 0,total_sum = 0 , val = 0;
	node* left = NULL , *right = NULL , * parent = NULL;
	node(string n , int v){
		name = n;
		val = v;
	}
};

void ancestory(node* n){
	if(n->left->left == NULL){
		//total sum
		n->total_sum = n->val + n->left->val + n->right->val;
		//side sum
		if(n->left->val > n->right->val){
			n->side_sum = n->val + n->left->val;
		}
		else{
			n->side_sum = n->val + n->right->val;
		}
		//lnode rnode
		n->lnode = n->left;
		n->rnode = n->right;
	}else{
		ancestory(n->left);
		ancestory(n->right);
		//total sum
		n->total_sum = n->left->side_sum + n->right->side_sum + n->val;
		
		//side sum
		if(n->left->side_sum > n->right->side_sum){
			n->side_sum = n->left->side_sum + n->val;
		}else{
			n->side_sum = n->right->side_sum + n->val;
		}
		//lnode and rnode
		if(n->right->rnode->val > n->right->lnode->val){
			n->rnode = n->right->rnode;
		}else{
			n->rnode = n->right->lnode;
		}
		if(n->left->rnode->val > n->left->lnode->val){
			n->lnode = n->left->rnode;
		}else{
			n->lnode = n->left->lnode;
		}

		if(n->total_sum < n->right->total_sum + n->val){
			n->total_sum = n->right->total_sum + n->val;
			n->side_sum = n->right->side_sum + n->val;
			n->lnode = n->right->lnode;
			n->rnode = n->right->rnode;
		}
		if(n->total_sum < n->left->total_sum + n->val){
			n->total_sum = n->left->total_sum + n->val;
			n->side_sum = n->left->side_sum + n->val;
			n->lnode = n->left->lnode;
			n->rnode = n->left->rnode;
		}

	}
}
int main(){
	string s = "X";
	srand(time(NULL));
	int n;
	cout << "Enter Size: " ;
	cin >> n;
	node* tree[n];
	int x = 0;
	cout << "Enter 1 to add manually :";
	cin >> x ;
	if(x){
		for(int i = 0 ; i < n ; i++){
			int v ;
			cin >> v;
			tree[i] = new node( s + std::to_string(i) , v);
		}
	}else{
		for (int i = 0; i < n; ++i){
			tree[i] = new node( s + std::to_string(i) , rand() % 100);
		}
	}
	for(int i = 0 ; i < n ; i++){
		if(2*i + 1 < n && 2*i + 2 < n){
			tree[i]->left = tree[2*i + 1];
			tree[i]->left->parent = tree[i];
			tree[i]->right = tree[2*i + 2];
			tree[i]->right->parent = tree[i];
		}
	}

	ancestory(tree[0]);
	cout << "Xi = " << tree[0]->rnode->name <<endl ;
	cout << "Xj = " << tree[0]->lnode->name <<endl;

	cout << "Value of Ancestory of ("<< tree[0]->rnode->name <<") : {" ;
	node * k = tree[0]->lnode;
	while(k != NULL){
		cout << k->val <<", ";
		k = k->parent ;
	}
	cout << "}"<<endl;
	
	cout << "Value of Ancestory of ("<< tree[0]->lnode->name <<") : {" ;
	k = tree[0]->rnode;
	while(k != NULL){
		cout << k->val <<", ";
		k = k->parent ;
	}
	cout << "}"<<endl;

	cout <<"Value of Max Ancestory ("<<tree[0]->lnode->name<<" , " << tree[0]->rnode->name <<"): " << tree[0]->total_sum <<endl;
	// cout << tree[0]->total_sum <<" "<< tree[0]->side_sum <<" "<<tree[0]->rnode->val<<" "<<tree[0]->lnode->val <<endl;
}