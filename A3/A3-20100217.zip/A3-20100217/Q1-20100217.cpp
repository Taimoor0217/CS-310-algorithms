// The implementation Gale Shapley' in my algorithm has been eecuted by using vector of structs. Each Airport/plane is a struct
// having a vector (of pointers) of it prefrences for Plane/Airport. There is also a field which identifies if an ariport/plane has already been assigned or not.
// A loop runs for n times in which another loop run on the prefrences of each of the planes. If that ppreference is already assigned (assigend != NULL) then I check if, the prefrence index of that airport was
// larger for which one of the planes. If it is larger for the one already at the spot, the new plane goes to its next preference, else it replaces the one at the airport and the replaced plane
// now becomes unasssigned. The same process runs untill all the planes have been assigned a port.
// P.S: Before adding a plane to an airport, I also check if that pair is not forbidden (in X vector);
// Space : O(n^2)
// Time  : O(n^2)   
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <stdio.h>
#include <string>
#include <fstream>
using namespace std;
struct Plane;

struct Airport{
	string name;
	bool assign = false;
	vector<Plane*> preferences;
	Plane * current = NULL;
	Airport(string n){
		name = n;
	}
	// vector<Plane*> current;
};

struct Plane{
	string name;
	bool assign = false;
	vector<Airport*> preferences;
	Plane(string n){
		name = n;
	}
};

struct unstable{
	string pl , air;
	unstable(string p , string a){
		pl = p ; air = a;
	}
};

Plane* findPlane(string n , vector<Plane*> &v){
	for(int i = 0 ; i < v.size(); i++){
		if(v[i]->name == n){
			return v[i];
		}
	}
	Plane * p = new Plane(n);
	v.push_back(p);
	return p ;
}
Airport* findAirport(string n , vector<Airport*> &v){
   	for(int i = 0 ; i < v.size(); i++){
   		if(v[i]->name == n){
   			return v[i];
   		}
   	}
	Airport * a = new Airport(n);
	v.push_back(a);
	return a;
}

int index(string p , string a , vector<Airport*> &v){
	for(int i = 0 ; i < v.size() ; i ++){
		if(v[i]->name == a ){
			for(int j = 0 ; j < v[i]->preferences.size() ; j++){
				if(v[i]->preferences[j]->name == p){
					// cout << p<<"-"<<j <<endl;
					return j ;
				}
			}
		}
	}
	return -1;
}
bool unstable_pair(string p , string a , vector<unstable*> &v){
	for(int i = 0 ; i < v.size() ; i ++){
		if(v[i]->pl == p && v[i]->air == a){
			return true;
		}
	}
	return false;
}

int main(){
	vector<Plane*> PLANES;
	vector<Airport*> AIRPORTS;
	vector<unstable*> forbidden;
	int n = 0;
	ifstream infile;
	infile.open("q1test2");
	string line;
	int x = 0;
	while(getline(infile , line)){
		vector<string> v;
		string temp;
		stringstream ss(line);
		while(getline(ss , temp, ' ')){
			v.push_back(temp);
		}
		if(x++){
			// int ind = 
			string name = v[0].substr(0,v[0].length() - 1);
			if(v[0][0] == 'P'){ //PlANE
				Plane * p = findPlane(name , PLANES);
				for(int i = 1 ; i < v.size() ; i ++){
					string a = v[i];
					if(a[a.length()-1] == ',')
						a = a.substr(0 , a.length()-1 );
					Airport * ap = findAirport(a , AIRPORTS);
					p->preferences.push_back(ap);
				}

			}else if(v[0][0] == 'A'){ //AIRPORT
				Airport * a = findAirport(name , AIRPORTS);
				for( int i = 1 ; i < v.size() ; i ++){
					string p = v[i];
					if(p[p.length()-1] == ',')
						p = p.substr(0 , p.length()-1 );
					Plane * pl = findPlane(p , PLANES);
					a->preferences.push_back(pl);
				}
			}else{
				for(int i = 1 ; i < v.size() ; i += 2 ){
					string a = v[i+1];
					if(a[a.length()-1] == ',')
						a = a.substr(0 , a.length()-1 );
						unstable* u = new unstable(v[i] , a );
						forbidden.push_back(u);
				}

			}
		}else{
			n = atoi(v[1].c_str());
		}
		// cout << line << endl; 
	}

	for(int i = 0 ; i < n ; i++ ){
		for(int j = 0 ; j < PLANES.size() ; j++){
			// cout << PLANES[j]->name <<endl;
		if( !PLANES[j]->assign){
			if(PLANES[j]->preferences[i]->current == NULL ){ //Iff Airpot is empty
				PLANES[j]->assign = true;
				PLANES[j]->preferences[i]->current = PLANES[j]; //Put the plane in Airport
				// cout << PLANES[j]->preferences[i]->name<<" "<<PLANES[j]->preferences[i]->current.size() <<" " << PLANES[j]->preferences[i]->current[0]->name <<endl; 
			}else if(
					index(PLANES[j]->preferences[i]->current->name , PLANES[j]->preferences[i]->name , AIRPORTS) 
					>=
					index(PLANES[j]->name, PLANES[j]->preferences[i]->name , AIRPORTS ) //if the preference of imcoming plane is greater that the one already present,
				  	// && (!PLANES[j]->assign)
				  	&& (!unstable_pair(PLANES[j]->name, PLANES[j]->preferences[i]->name , forbidden ))
				  ){
				  	PLANES[j]->preferences[i]->current->assign = false; //Replace the plane and set their assignments accordingly
				  	PLANES[j]->assign = true;
				  	PLANES[j]->preferences[i]->current = PLANES[j];
				  	j = 0;
					// cout << PLANES[j]->preferences[i]->name<<" "<<PLANES[j]->preferences[i]->current.size() <<" " << PLANES[j]->preferences[i]->current[0]->name <<endl; 
				}
			}
		}
	}
	for(int i = 0 ; i < AIRPORTS.size() ; i ++){
		// cout << AIRPORTS[i]->name <<" "<< AIRPORTS[i]->current.size()<<endl;
		cout << AIRPORTS[i]->name <<" "<< AIRPORTS[i]->current->name<<endl;
	}		
	return 0 ;
}