// Algorithm: The algorithm starts by divinding the array into subarrays of half the size, the base case is when I hit an array of size 2, This is when 
// I call decode which tells, if the two images at the array are of same specie or not and then increment the species array indices accordingly. If at any point the index value increses
// n/2, it returns and prints. 
// Data Structures: Arrays of size m to keep the frequencies. Array of size n to keep the photos.
// Space: O(n+m)
// Time: O(n + log(n)) = O(n)
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string>
bool p = false;
int a = 0;
using namespace std;
bool decode(int p1 , int p2){
	if(p1 == p2)
		return true;
	else
		return false;
}
void calculate(int i , int j, int* photos , int* species , int n , int m){
	if(i+1 < j){
		calculate(i , (i+j)/2 , photos , species , n , m );
		calculate(((i+j)/2)+1 , j , photos , species , n , m );
	}
	if(i+1 == j){
		if(decode(photos[i] , photos[j])){
			species[photos[i]] += 2;
		}else{
			species[photos[i]]++;
			species[photos[j]]++;
		}
		if(species[photos[i]] > n/2 && !p){
			a = photos[i];
			cout << "Success, " <<"Specie "<< photos[i] << " has more than n/2 photos."<< endl;
			p = true;
		}
		if(species[photos[j]] > n/2 && !p){
			a = photos[i];
			cout << "Success, " <<"Specie "<< photos[j] << " has  more than n/2 photos."<< endl;
			p = true;
		}
		return;
	}
}
int main(){
	srand(time(NULL));
	int n , m ;
	cout << "Enter the Value of n :" ;
	cin >> n;
	cout << "Enter the Value of m :" ;
	cin >> m;
	int *photos = new int[n];
	int *species = new int[m];
	for(int i = 0 ; i < m ; i++){
		species[i] = 0;
	}
	int x = 0;
	cout << "Enter 1 to add manually :";
	cin >> x ;
	if(x){
		for(int i = 0 ; i < n ; i++){
			cin >> photos[i];
		}
	}else{
		for(int i = 0 ; i < n ; i++){
			photos[i] = rand() % m ;
		}
	}

	cout <<"[ ";
	for(int i = 0 ; i < n ; i++){
		cout << photos[i] <<", ";
	}
	cout <<"] " <<endl;
	calculate(0 , n-1 ,photos , species , n , m );
	if(!p){
		cout << "Failure " <<endl;
	}
	cout <<"[ ";
	for(int k = 0 ; k < n ; k++){
		if(photos[k] == a){
			cout << k <<",";
		}
	}
	cout <<"] " <<endl;
	return 0;
}