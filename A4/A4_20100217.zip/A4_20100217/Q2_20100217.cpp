// Recurence Relation: 
	// minimize(m , n , s) = 0     :- m.size() = 0
	// minimize(m , n , s) =   i (min (n + minimize(l_m, s, m[i]-s) + minimize(r_m,m[i],n+s - m[i]))
	// 						 1 to n 
// At each step I get two subproblems after cutting at a point, one is the area of the scale to the right pf the cut with the cuts which lie in that region
// the other is the area of the scal to the left of the cut.
// TIME COMPLEXIY: O(m!) , where m is the number of cut points. 
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <string>
using namespace std;
int **memo;
int *lev;
int n = 0 ;
std::vector<int> m;

int present(int j){
	for(int i = 0 ; i < m.size()+1 ; i++){
		if(lev[i] == j ){
			return 1;
		}
	}
	return 0;
}
int ind(int i){
	for(int k = 0 ; m.size() ; k++ ){
		if(memo[k][0] == i){
			return k;
		}
	}
	return -1;
}
int min(int a , int b){
	if(a < b ){
		return a;
	}else{
		return b;
	}
}
int minimize(vector<int> m , int s, int n,int l ){
	if(m.size() == 0){
		return 0;
	}
	else{
		int q = 1000000;
		vector<int> sol;
		for(int i = 0 ; i < m.size() ; i++){
			int index = ind(m[i]);
			std::vector<int> l_temp;
			std::vector<int> r_temp;
			for(int j = 0 ; j < m.size() ; j++ ){
				if(m[j] != m[i]){
					if(m[j] < m[i]){
						l_temp.push_back(m[j]);
					}else{
						r_temp.push_back(m[j]);
					}
				}
			}
			int k = q;
			q = min(q,n+minimize(l_temp, s , m[i]-s,l+1 )+minimize(r_temp,m[i],n+s - m[i],l+1));
			// if(k > q){
			memo[index][n] = q;
			// }
			sol.push_back(q);
		}
		int IND = 0 , val = sol[0];
		for(int i =0 ; i < sol.size() ; i++){
			if(sol[i] < val){
				val = sol[i];
				IND = i;
			}
		}
		if(l != 1){
			if(!present(m[IND])){
				lev[l] = m[IND];
			}
		}else{
			lev[l] = m[IND];
		}
		return q;
	} 
}

int main(){
	ifstream infile;
	infile.open("q2test");
	string line;
	int c = 0;
	while(getline(infile , line)){
		stringstream ss(line);
		string temp;
		vector<string> v;
		while(getline(ss , temp ,' ')){
			v.push_back(temp);
		}
		if(c++){
			for(int i = 1 ; i < v.size() ; i++){
				m.push_back(atoi(&v[i][0]));
			}
		}else{
			n = atoi(&v[1][0]);
		}
	}
	memo = new int*[m.size()];
	for(int i =0 ; i < m.size() ; i ++){
		memo[i] = new int[n+1];
		std::fill_n(memo[i],n+1,-1);
		memo[i][0] = m[i];
	}
	lev =new int[m.size()+1];	
	cout << minimize(m, 0, n, 1) << endl;
 // 	for(int i =0 ; i < m.size() ; i++){
	// 	for(int j =0 ; j < n+1 ; j ++){
	// 		cout << memo[i][j] << " ";
	// 	}cout << endl << endl;
	// 	// cout << memo[i][0]<<" "<< memo[i][n] << endl;
	// }
	for(int i = 1 ; i < m.size() +1 ; i++){
		cout << lev[i] <<" ";
	}
}