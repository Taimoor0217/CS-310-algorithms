// RECCURENCE:
//check(s1,s2,s3) = true    :- s1.len == 0 || s2.len == 0
//  				 check(s1.substr( 1,s1.length()-1) , s2 , s3.substr(1,s3.length()-1))
//check(s1,s2,s3) =									||
// 					 check(s1 ,s2.substr(1,s2.length()-1), s3.substr(1,s3.length()-1));
// At each step my problem gets dicided into two problems, a) if the first character of s1||s2 matches s3 , b) if does not matches any
// TIME COMPLEXITY = O(n)
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <string>
using namespace std;
// merges
// mmiergreeds
// mmiergreeds
bool check(string s1 , string s2, string s3){
	if(s3.length() == 0 && (s1.length()||s2.length())){
		return false;
	}else if(s1.length() == 0 || s2.length() == 0){
		if(s1.length() == 0){
			cout << "S2:" << s2 <<" ";
		}
		if(s2.length() == 0){
			cout << "S1:" << s1 <<" ";
		}
		return true;
	}else if(s1[0] != s3[0] && s2[0] != s3[0]){
		return false;
	}else{
		if(s1[0] == s3[0] && s2[0] == s3[0]){
			cout << "S1:" << s3[0] <<" ";
			return 
				check(s1.substr( 1,s1.length()-1) , s2 , s3.substr(1,s3.length()-1))
				||
				check(s1 ,s2.substr(1,s2.length()-1), s3.substr(1,s3.length()-1));
		}else if(s1[0] == s3[0] && s2[0] != s3[0]){
			cout << "S1:" << s3[0] <<" ";
			return check(s1.substr( 1,s1.length()-1) , s2 , s3.substr(1,s3.length()-1));
		}else if(s1[0] != s3[0] && s2[0] == s3[0]){
			cout << "S2:" << s3[0] <<" ";
			return check(s1 ,s2.substr(1,s2.length()-1), s3.substr(1,s3.length()-1));
		}
	}
}
int main(){
	string s1,s2,s3;
	fstream infile;
	infile.open("q4test");
	vector<string> v;
	string line;
	while(getline(infile , line)){
		v.push_back(line);
	}
	s1 = v[0];s2 = v[1];s3 = v[2];
	if(check(s1 ,s2 , s3)){
		cout << endl<<"VALID" <<endl;
	}else{
		cout<<endl;
		system("clear") ;
		cout << "INVALID " <<endl;
	}
}