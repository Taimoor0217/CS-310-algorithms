// RECCURENCE RELATION: 
// maximize(0) = 0
// maximize(i) = max(job(i).low + maximize(i-1) , job(i).high +maximize(i-2))

// As it can be seen from the recurence relation that, at each step my subproblems are the 
// jobs of the week i-1 or the week i-2.
// TIME COMPLEXITY: After memoization, the time complexity is O(n)
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <stdio.h>
#include <string>
using namespace std;
struct job{
	int RH , RL;
};
struct mem{
	int val = -1;
	bool high = false,low = false, prim = false;
};
int max(int a , int b){
	if(a > b)
		return a;
	else
		return b;
}
job * JOBS;
mem * memo;
int x = 0 ;


int maximize(int i){
	if(i < 0){
		return 0;
	}else{
		if(memo[i].val == -1){
			memo[i-1].val = maximize(i-1);
			memo[i-2].val = maximize(i-2);
			if(JOBS[i].RL + memo[i-1].val >= JOBS[i].RH + memo[i-2].val){
				memo[i].low = true; memo[i].high = false; memo[i].prim = false;
			}else{
				memo[i].high = true; memo[i].low = false; memo[i].prim = false;
				memo[i-1].prim = true; memo[i-1].high = false; memo[i-1].low = false;
				if(memo[i-2].prim ){
					memo[i-2].prim = false; memo[i-2].high = false; memo[i-2].low = true;
				}
			}
			memo[i].val = max(JOBS[i].RL + memo[i-1].val , JOBS[i].RH + memo[i-2].val); 
			return memo[i].val;
		}else{
			return memo[i].val;
		}
	}
}
int main(){
	ifstream infile;
	infile.open("testpart1");
	string line;
	int n = 0;
	while(getline(infile , line)){
		stringstream ss(line);
		string temp;
		vector<string> v;
		while(getline(ss , temp ,' ')){
			v.push_back(temp);
		}
		if(n > 0){
			for(int i = 1 ; i < v.size() ; i++){
				if(n == 1 ){
					JOBS[i-1].RH = atoi(&v[i][0]);
				}else if(n == 2){
					JOBS[i-1].RL = atoi(&v[i][0]);
				}
			}

		}else{
			x = atoi(&v[1][0]);
			JOBS = new job[x];
			memo = new mem[x];
		}
		n++;
	}
	int rev = maximize(x-1) ;
	for(int i = 0 ; i < x ;i++){
		if(memo[i].high){
			cout << "WEEK" << i+1 <<" HIGH: " << JOBS[i].RH << endl;
		}else if(memo[i].low){
			cout << "WEEK" << i+1 <<" LOW: " << JOBS[i].RL<< endl;
		}else if(memo[i].prim){
			cout << "WEEK" << i+1 <<" PRIMING: " << 0 << endl;
		}
	}
	cout << "TOTAL REVENUE: "<< rev <<endl;
}