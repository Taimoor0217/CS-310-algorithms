// The function make square recursivley finds all the possible subsquares of the given square and find their
//  sum. It the poshes those subsquares into a global vector. Then I linearly traverse that vector to find the square with the maximum sum value.
// TIME COMPLEXITY: O(n^4) :- n being the dimension of the square.


// COPY PASTE THE ARRAY IN THE MAIN FUNCTION TO TEST MANUALLY.
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string>
using namespace std;
struct square{
	int x = 0, y = 0 , size = 0 , sum = 0;
	square(int i , int j , int s , int su){
		x = i; y = j ; size = s ; sum = su;
	}
};
vector<square> v;
square max(){
	int m = v[0].sum;
	int ind = 0;
	for(int i = 0 ; i < v.size() ; i++){
		if(v[i].sum > m){
			m = v[i].sum;
			ind = i;
		}
	}
	return v[ind];
}
int sum(int** sqr , int k , int l , int s){
	int S = 0,i = k , j = l;
	for(i = k; i < k+s; i++){
		for(j = l ; j < l+s; j++){
			S += sqr[i][j];
		}
	}
	return S;
}
void makesquares(int** sqr , int d , int s){
	if(s > d){
		return;
	}else{
		for(int i = 0 ; i < d ; i ++){
			for(int j = 0; j < d ; j++){
				if(i+s <= d && j+s <= d){
					int SUM = sum(sqr , i, j, s);
					square S(i, j, s, SUM);
					v.push_back(S);
				}
			}
		}
		makesquares(sqr , d , s+1);
	}
}

int main(){
	int d = 5;
	int array[25] = { 1, 8, 33, -1, 20,
-10, 2, 23, -7, 27,
-27, 8, 6, 7, 32,
-25, 4, -67, 4, 4,
3, 11, 5, 4, 5 };
	srand(time(NULL));
	int x = 0;
	int ** sqr;
	cout << "PRESS anything non zero for random Square :" ;cin >> x ; 
	if(x){
		cout << "Enter Dimesnsion:" ;cin >> d;
		sqr = new int*[d];
		for(int i = 0 ; i < d ; i ++){
			sqr[i] = new int[d];
		}
		for(int i = 0 ; i < d ; i ++){
			for(int j = 0 ; j < d ; j++){
				sqr[i][j] = rand()%100 ;
			}
		}
	}else{
		int count = 0;
		sqr = new int*[d];
		for(int i = 0 ; i < d ; i ++){
			sqr[i] = new int[d];
		}
		for(int i = 0 ; i < d ; i ++){
			for(int j = 0 ; j < d ; j++){
				sqr[i][j] = array[count++];
			}
		}
	}

	for(int i = 0 ; i < d ; i ++){
		for(int j = 0 ; j < d ; j++){
			cout << sqr[i][j] <<" ";
		}cout << endl;
	}
	makesquares(sqr, d ,1);
	square maxsq = max();
	cout <<"HEIGHT :"<< maxsq.size << endl;
	cout <<"TOP RIGHT ("<< maxsq.x <<","<< maxsq.y <<")"<<endl;
	int r = maxsq.x + maxsq.size, c = maxsq.y + maxsq.size ;
	cout <<"BOTTOM RIGHT ("<< r-1 <<","<< c-1 <<")"<< endl;
	cout <<"MAX SUM: " << maxsq.sum <<endl;
}