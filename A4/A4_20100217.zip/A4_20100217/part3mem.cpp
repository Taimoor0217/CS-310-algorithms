#include <iostream>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <string>
using namespace std;
int S1  = 0, S2 = 0;
int * memo;
std::vector<int> n;
std::vector<int> s2;
int ind(int i){
	for(int k = 0 ; n.size() ; k++ ){
		if(n[k] == i){
			return k;
		}
	}
	return -1;
}
int present(int k , vector<int> v){
	for(int i =0 ; i < v.size() ; i++){
		if(v[i] == k){
			return 1;
		}
	}
	return 0;
}
int sum(vector<int> v){
	int sum = 0 ;
	for(int i = 0 ; i < v.size() ; i++){
		sum += v[i];
	}
	return sum;
}
int indgreatest(std::vector<int> v){
	int ind = 0 , val = v[0];
	for(int i =0 ; i < v.size() ; i++){
		if(v[i] > val){
			val = v[i];
			ind = i;
		}
	}
	return ind;
}
bool makesets(int sum1 , int sum2 ,int k, vector<int> v , int l){
	if(sum1 - sum2 == k){
		// cout << sum1 <<" " << sum2 << endl;
		S1 = sum1 ;
		S2 = sum2 ;
		return true;
	}else if(v.size() == 0){
		return false;
	}else{
		bool q = false,x,y ;
		for(int i = 0 ; i < v.size() ; i++){
			std::vector<int> temp;
			for(int j = 0 ; j < v.size() ; j ++){
				if(v[j] != v[i]){
					temp.push_back(v[j]);
				}
			}
			x = makesets(sum1 - v[i] , sum2 + v[i] , k , temp , l+1); 
			y =  makesets(sum1 , sum2 , k , temp ,l+1) ;
			q = x || y ;
			if(x && l == 1 ){
				s2.push_back(v[i]);
			}
		}
		return q;
	}
		
}
int main(){
	int k = 0 ;
	ifstream infile;
	infile.open("q3test");
	string line;
	int c = 0;
	while(getline(infile , line)){
		stringstream ss(line);
		string temp;
		vector<string> v;
		while(getline(ss , temp ,' ')){
			v.push_back(temp);
		}
		if(c++){
			for(int i = 1 ; i < v.size() ; i++){
				n.push_back(atoi(&v[i][0]));
			}
		}else{
			k = atoi(&v[1][0]);
		}
	}
	memo = new int[n.size()];
	for(int i = 0 ; i < n.size() ; i++){
		memo[i] = -1;
	}
	int sum1 = 0;
	for(int i = 0 ; i < n.size() ; i ++){
		sum1 += n[i];
	}
	bool sets;
	sets = makesets(sum1, 0 , k , n , 1);
	std::vector<int> set1;
	if(sets){
		cout << "POSSIBLE " <<endl;
		cout <<"SUM1 = "<< S1 << endl<< "SUM2 = " << S2 <<endl;
	}
	if(sets){
		while(sum(s2) != S2 && sum(s2)){
			int ind = indgreatest(s2);
			set1.push_back(s2[ind]);
			s2[ind] = 0;
		}
		for(int i = 0 ; i < n.size() ; i ++){
			if(!present(n[i] , s2) && !present(n[i] , set1)){
				set1.push_back(n[i]);
			}
		}
		cout << "Set1: ";
		for(int i = 0 ; i < set1.size() ; i ++){
			cout << set1[i] <<" ";
		}cout <<"SUM = " << S1 << endl;
		cout << "Set2: ";
		for(int i = 0 ; i < s2.size() ; i++){
			if(s2[i] != 0){
				cout << s2[i] << " " ;
			}
		}cout <<"SUM = " << S2 << endl;
		cout << "DIFFERENCE: " << S1 <<"-"<< S2 <<" = "<< k << endl;
	}else{
		cout << "NOT POSSIBLE " << endl;
	}
}
